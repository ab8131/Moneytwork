package com.example.moneytwork

import androidx.compose.runtime.Composable

@Composable
fun MoneytworkDevApp() {
    // TODO: Paste Moneytworkdev's original setContent { ... } content here if needed.
}
