package com.example.moneytwork

import android.app.Application
class MoneytworkApplication : Application()

