package com.example.eco.ui.theme

import androidx.compose.ui.graphics.Color

// Global app background: dark blue.
val EcoDarkBlue = Color(0xFF071A33)

// Supporting colors.
val EcoPrimary = Color(0xFF4DA3FF)
val EcoOnDark = Color(0xFFFFFFFF)
val EcoError = Color(0xFFFF6B6B)
