package com.example.eco

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.moneytwork.core.util.Resource
import com.example.moneytwork.domain.repository.CryptoRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val loading: Boolean = false,
    val error: String = "",
    val topics: List<TopicAsset> = emptyList()
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val cryptoRepository: CryptoRepository,
) : ViewModel() {

    private val _ui = MutableStateFlow(HomeUiState(loading = true))
    val ui: StateFlow<HomeUiState> = _ui

    // Same list as moneytworkdev StockListViewModel to stay consistent with Eco.
    private val stockTopics = listOf(
        TopicAsset("stock", "AAPL", "Apple", "AAPL"),
        TopicAsset("stock", "MSFT", "Microsoft", "MSFT"),
        TopicAsset("stock", "GOOGL", "Alphabet", "GOOGL"),
        TopicAsset("stock", "AMZN", "Amazon", "AMZN"),
        TopicAsset("stock", "TSLA", "Tesla", "TSLA"),
        TopicAsset("stock", "META", "Meta", "META"),
        TopicAsset("stock", "NVDA", "NVIDIA", "NVDA"),
        TopicAsset("stock", "JPM", "JPMorgan", "JPM"),
        TopicAsset("stock", "V", "Visa", "V"),
        TopicAsset("stock", "WMT", "Walmart", "WMT"),
        TopicAsset("stock", "DIS", "Disney", "DIS"),
        TopicAsset("stock", "NFLX", "Netflix", "NFLX"),
        TopicAsset("stock", "BA", "Boeing", "BA"),
        TopicAsset("stock", "COIN", "Coinbase", "COIN"),
        TopicAsset("stock", "AMD", "AMD", "AMD"),
    )

    init {
        refreshTopics()
    }

    fun refreshTopics() = viewModelScope.launch {
        _ui.value = HomeUiState(loading = true)

        val crypto = runCatching {
            // Get first terminal value that is not Loading.
            cryptoRepository.getCoins(forceRefresh = false).first { it !is Resource.Loading }
        }

        val cryptoTopics = (crypto.getOrNull() as? Resource.Success)?.data
            ?.take(50)
            ?.map { c ->
                TopicAsset(
                    type = "crypto",
                    key = c.id,
                    name = c.name,
                    symbol = c.symbol.uppercase()
                )
            }
            ?: emptyList()

        val err = (crypto.getOrNull() as? Resource.Error)?.message
            ?: crypto.exceptionOrNull()?.message
            ?: ""

        _ui.value = HomeUiState(
            loading = false,
            error = err,
            topics = (stockTopics + cryptoTopics)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedPage(
    repo: FirebaseRepo,
    goProfile: () -> Unit,
    openTopic: (TopicAsset) -> Unit,
    vm: HomeViewModel = hiltViewModel()
) {
    val ui by vm.ui.collectAsState()
    var query by remember { mutableStateOf("") }
    var showCreate by remember { mutableStateOf(false) }

    val filtered = remember(ui.topics, query) {
        if (query.isBlank()) ui.topics
        else ui.topics.filter {
            it.name.contains(query, ignoreCase = true) ||
                it.symbol.contains(query, ignoreCase = true) ||
                it.key.contains(query, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Accueil") },
                actions = {
                    TextButton(onClick = goProfile) { Text("Profil") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreate = true }) {
                Icon(Icons.Default.Add, contentDescription = "Créer un post")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                label = { Text("Rechercher un sujet (crypto / stock)") },
                singleLine = true
            )

            Spacer(Modifier.height(12.dp))

            if (ui.loading) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
            }

            if (ui.error.isNotBlank()) {
                Text(ui.error, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(12.dp))
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text("Stocks", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                items(filtered.filter { it.type == "stock" }) { t ->
                    TopicRow(t, onClick = { openTopic(t) })
                }
                item { Spacer(Modifier.height(10.dp)) }
                item {
                    Text("Cryptos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                items(filtered.filter { it.type == "crypto" }) { t ->
                    TopicRow(t, onClick = { openTopic(t) })
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    if (showCreate) {
        CreatePostDialog(
            repo = repo,
            topics = ui.topics,
            onDismiss = { showCreate = false },
            onPosted = { topic ->
                showCreate = false
                openTopic(topic)
            }
        )
    }
}

@Composable
private fun TopicRow(topic: TopicAsset, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(topic.symbol, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(topic.name, style = MaterialTheme.typography.bodyMedium)
            }
            Text(">", style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun CreatePostDialog(
    repo: FirebaseRepo,
    topics: List<TopicAsset>,
    onDismiss: () -> Unit,
    onPosted: (TopicAsset) -> Unit,
) {
    var topicQuery by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<TopicAsset?>(null) }
    var text by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    val filtered = remember(topics, topicQuery) {
        val base = if (topicQuery.isBlank()) topics else topics.filter {
            it.name.contains(topicQuery, ignoreCase = true) ||
                it.symbol.contains(topicQuery, ignoreCase = true)
        }
        base.take(30)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Créer un post") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = topicQuery,
                    onValueChange = {
                        topicQuery = it
                        // reset selection if it no longer matches
                        if (selected != null && it.isNotBlank() &&
                            !(selected!!.name.contains(it, true) || selected!!.symbol.contains(it, true))
                        ) selected = null
                    },
                    label = { Text("Sujet (crypto / stock)") },
                    placeholder = { Text("Ex: BTC, AAPL, Bitcoin…") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (selected == null) {
                    Card {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 220.dp)
                        ) {
                            items(filtered) { t ->
                                ListItem(
                                    headlineContent = { Text("${t.symbol} — ${t.name}") },
                                    supportingContent = { Text(if (t.type == "crypto") "Crypto" else "Stock") },
                                    modifier = Modifier.clickable {
                                        selected = t
                                        topicQuery = "${t.symbol} — ${t.name}"
                                    }
                                )
                            }
                        }
                    }
                } else {
                    Text(
                        "Sujet sélectionné: ${selected!!.symbol} — ${selected!!.name}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Votre post") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )

                if (error.isNotBlank()) {
                    Text(error, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !loading,
                onClick = {
                    val t = selected
                    if (t == null) {
                        error = "Choisis un sujet."
                        return@TextButton
                    }
                    if (text.trim().length < 2) {
                        error = "Ton post est trop court."
                        return@TextButton
                    }
                    loading = true
                    error = ""
                    scope.launch {
                        runCatching {
                            repo.createTopicPost(t.type, t.key, t.name, text.trim())
                        }.onSuccess {
                            onPosted(t)
                        }.onFailure {
                            error = it.message ?: "Erreur"
                        }
                        loading = false
                    }
                }
            ) {
                if (loading) {
                    CircularProgressIndicator(Modifier.size(18.dp))
                } else {
                    Text("Publier")
                }
            }
        },
        dismissButton = {
            TextButton(enabled = !loading, onClick = onDismiss) { Text("Annuler") }
        }
    )
}
