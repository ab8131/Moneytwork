package com.example.eco

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.moneytwork.presentation.navigation.Screen

private data class EcoMenuItem(
    val title: String,
    val subtitle: String,
    val route: String,
    val requiresParam: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EcoPage(
    nav: NavHostController,
    goHome: () -> Unit,
    goProfile: () -> Unit
) {
    val menu = remember {
        listOf(
            EcoMenuItem(
                title = "Portfolio",
                subtitle = "Aperçu du portefeuille (Moneytwork)",
                route = "portfolio"
            ),
            EcoMenuItem(
                title = "Crypto Market",
                subtitle = "Liste & tendances des cryptos",
                route = "crypto"
            ),
            EcoMenuItem(
                title = "Stocks",
                subtitle = "Liste des actions",
                route = "stocks"
            ),
            EcoMenuItem(
                title = "Search",
                subtitle = "Recherche (Moneytwork)",
                route = Screen.Search.route
            ),
            EcoMenuItem(
                title = "Coin detail",
                subtitle = "Détail d’une crypto (coinId requis)",
                route = Screen.CoinDetail.route,
                requiresParam = true
            ),
            EcoMenuItem(
                title = "Stock detail",
                subtitle = "Détail d’une action (symbol requis)",
                route = "stock_detail/{symbol}",
                requiresParam = true
            )
        )
    }

    var showCoinDialog by remember { mutableStateOf(false) }
    var showStockDialog by remember { mutableStateOf(false) }
    var coinId by remember { mutableStateOf("") }
    var stockSymbol by remember { mutableStateOf("") }

    if (showCoinDialog) {
        AlertDialog(
            onDismissRequest = { showCoinDialog = false },
            title = { Text("Coin detail") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Entre le coinId (ex: bitcoin)")
                    OutlinedTextField(
                        value = coinId,
                        onValueChange = { coinId = it },
                        singleLine = true,
                        label = { Text("coinId") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val id = coinId.trim()
                        if (id.isNotEmpty()) {
                            nav.navigate(Screen.CoinDetail.createRoute(id))
                            showCoinDialog = false
                        }
                    }
                ) {
                    Text("Ouvrir")
                }
            },
            dismissButton = {
                Button(onClick = { showCoinDialog = false }) { Text("Annuler") }
            }
        )
    }

    if (showStockDialog) {
        AlertDialog(
            onDismissRequest = { showStockDialog = false },
            title = { Text("Stock detail") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Entre le symbol (ex: AAPL)")
                    OutlinedTextField(
                        value = stockSymbol,
                        onValueChange = { stockSymbol = it },
                        singleLine = true,
                        label = { Text("symbol") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val sym = stockSymbol.trim()
                        if (sym.isNotEmpty()) {
                            nav.navigate("stock_detail/$sym")
                            showStockDialog = false
                        }
                    }
                ) {
                    Text("Ouvrir")
                }
            },
            dismissButton = {
                Button(onClick = { showStockDialog = false }) { Text("Annuler") }
            }
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item {
                Text("Eco", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Menu Moneytwork : accès aux écrans de la lib moneytworkdev.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(8.dp))
            }

            items(menu) { item ->
                Card(
                    colors = CardDefaults.cardColors(),
                    modifier = Modifier.clickable {
                        when (item.route) {
                            Screen.CoinDetail.route -> showCoinDialog = true
                            "stock_detail/{symbol}" -> showStockDialog = true
                            else -> nav.navigate(item.route)
                        }
                    }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(item.title, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(item.subtitle, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = goHome,
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
                ) { Text("Accueil") }

                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = goProfile,
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
                ) { Text("Profil") }
            }
        }
    }
}
