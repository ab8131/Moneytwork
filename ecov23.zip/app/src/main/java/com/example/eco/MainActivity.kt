package com.example.eco

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.*
import com.example.moneytwork.presentation.market.detail.DetailScreen
import com.example.moneytwork.presentation.market.list.MarketListScreen
import com.example.moneytwork.presentation.portfolio.PortfolioScreen
import com.example.moneytwork.presentation.search.SearchScreen
import com.example.moneytwork.presentation.stocks.StockListScreen
import com.example.moneytwork.presentation.stocks.detail.StockDetailScreen
import com.example.eco.ui.theme.EcoTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val repo = FirebaseRepo()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            EcoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val nav = rememberNavController()
                    val start = if (repo.uid() == null) "auth" else "feed"

                    val backStackEntry by nav.currentBackStackEntryAsState()
                    val currentRoute = backStackEntry?.destination?.route

                    val showBottomBar = currentRoute == "eco" || currentRoute == "feed" || currentRoute == "profile"

                    Scaffold(
                        containerColor = MaterialTheme.colorScheme.background,
                    bottomBar = {
                        if (showBottomBar) {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.background
                            ) {
                                val currentDestination = backStackEntry?.destination
                                val items = listOf(
                                    BottomItem("eco", "Eco", Icons.Filled.Menu),
                                    BottomItem("feed", "Accueil", Icons.Filled.Home),
                                    BottomItem("profile", "Profil", Icons.Filled.Person)
                                )

                                items.forEach { item ->
                                    val selected =
                                        currentDestination?.hierarchy?.any { it.route == item.route } == true

                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = {
                                            nav.navigate(item.route) {
                                                popUpTo("feed") { inclusive = false }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        },
                                        icon = { Icon(item.icon, contentDescription = item.label) },
                                        label = { Text(item.label) }
                                    )
                                }
                            }
                        }
                    }
                ) { paddingValues ->
                        NavHost(
                            navController = nav,
                            startDestination = start,
                            modifier = Modifier.padding(paddingValues)
                        ) {
                        composable("auth") {
                            AuthPage(
                                repo = repo,
                                onAuthed = {
                                    nav.navigate("feed") {
                                        popUpTo("auth") { inclusive = true }
                                    }
                                }
                            )
                        }

                        composable("feed") {
                            FeedPage(
                                repo = repo,
                                goProfile = { nav.navigate("profile") { launchSingleTop = true } }
                                ,
                                openTopic = { t -> nav.navigate(t.feedRoute) }
                            )
                        }

                        composable("feed_topic/{topicType}/{topicKey}/{topicSymbol}") { entry ->
                            val type = entry.arguments?.getString("topicType") ?: ""
                            val key = entry.arguments?.getString("topicKey") ?: ""
                            val sym = entry.arguments?.getString("topicSymbol") ?: ""
                            TopicFeedPage(
                                repo = repo,
                                topicType = type,
                                topicKey = key,
                                topicLabel = sym.ifBlank { "$type:$key" },
                                onBack = { nav.popBackStack() }
                            )
                        }

                        composable("eco") {
                            EcoPage(
                                nav = nav,
                                goHome = { nav.navigate("feed") { launchSingleTop = true } },
                                goProfile = { nav.navigate("profile") { launchSingleTop = true } }
                            )
                        }

                        // MoneytworkDev screens (access via Eco)
                        composable("portfolio") { PortfolioScreen(navController = nav) }
                        composable("crypto") { MarketListScreen(navController = nav) }
                        composable("stocks") { StockListScreen(navController = nav) }
                        composable("search") { SearchScreen(navController = nav) }

                        composable("coin_detail/{coinId}") { DetailScreen(navController = nav) }
                        composable("stock_detail/{symbol}") { StockDetailScreen(navController = nav) }

                        composable("profile") {
                            ProfilePage(
                                repo = repo,
                                onLoggedOut = {
                                    nav.navigate("auth") {
                                        popUpTo("feed") { inclusive = true }
                                    }
                                }
                            )
                        }
                        }
                    }
                }
            }
        }
    }
}

data class BottomItem(
    val route: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)
