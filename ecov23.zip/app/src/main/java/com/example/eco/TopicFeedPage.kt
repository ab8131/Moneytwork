package com.example.eco

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopicFeedPage(
    repo: FirebaseRepo,
    topicType: String,
    topicKey: String,
    topicLabel: String,
    onBack: () -> Unit
) {
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var posts by remember { mutableStateOf<List<PostData>>(emptyList()) }
    val scope = rememberCoroutineScope()
    val df = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }

    fun refresh() {
        loading = true
        error = ""
        scope.launch {
            runCatching { repo.getTopicPosts(topicType, topicKey) }
                .onSuccess { posts = it }
                .onFailure { error = it.message ?: "Erreur" }
            loading = false
        }
    }

    LaunchedEffect(topicType, topicKey) { refresh() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(topicLabel) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    TextButton(onClick = { refresh() }) { Text("Actualiser") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp)
        ) {
            if (loading) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
            }
            if (error.isNotBlank()) {
                Text(error, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(12.dp))
            }
            if (!loading && posts.isEmpty() && error.isBlank()) {
                Text("Aucun post pour ce sujet.")
                Spacer(Modifier.height(12.dp))
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(posts) { p ->
                    PostCard(
                        repo = repo,
                        topicType = topicType,
                        topicKey = topicKey,
                        post = p,
                        dateLabel = df.format(Date(p.createdAt)),
                        onInteracted = { refresh() }
                    )
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }
}

@Composable
private fun PostCard(
    repo: FirebaseRepo,
    topicType: String,
    topicKey: String,
    post: PostData,
    dateLabel: String,
    onInteracted: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var showComments by remember { mutableStateOf(false) }
    var commentText by remember { mutableStateOf("") }
    var comments by remember { mutableStateOf<List<CommentData>>(emptyList()) }
    var loadingComments by remember { mutableStateOf(false) }

    fun loadComments() {
        loadingComments = true
        scope.launch {
            comments = runCatching { repo.getComments(topicType, topicKey, post.id) }.getOrDefault(emptyList())
            loadingComments = false
        }
    }

    Card {
        Column(Modifier.padding(12.dp)) {
            Text(post.text, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(8.dp))
            Text(dateLabel, style = MaterialTheme.typography.labelSmall)

            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val quick = listOf("👍", "🚀", "🔥", "😂", "😢")
                quick.forEach { e ->
                    AssistChip(
                        onClick = {
                            scope.launch {
                                repo.addReaction(topicType, topicKey, post.id, e)
                                onInteracted()
                            }
                        },
                        label = { Text("$e ${post.reactions[e] ?: 0L}") }
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            Text(
                if (showComments) "Masquer les commentaires" else "Voir les commentaires",
                modifier = Modifier.clickable {
                    showComments = !showComments
                    if (showComments) loadComments()
                },
                style = MaterialTheme.typography.labelLarge
            )

            if (showComments) {
                Spacer(Modifier.height(8.dp))

                if (loadingComments) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                }

                comments.forEach { c ->
                    Text("• ${c.text}", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                }

                OutlinedTextField(
                    value = commentText,
                    onValueChange = { commentText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Commenter") },
                    singleLine = true
                )

                Spacer(Modifier.height(6.dp))

                Button(
                    onClick = {
                        val t = commentText.trim()
                        if (t.isBlank()) return@Button
                        commentText = ""
                        scope.launch {
                            repo.addComment(topicType, topicKey, post.id, t)
                            loadComments()
                            onInteracted()
                        }
                    }
                ) { Text("Publier") }
            }
        }
    }
}
