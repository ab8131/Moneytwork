package com.example.eco.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val EcoColorScheme = darkColorScheme(
    primary = EcoPrimary,
    onPrimary = Color.Black,
    background = EcoDarkBlue,
    onBackground = EcoOnDark,
    surface = EcoDarkBlue,
    onSurface = EcoOnDark,
    error = EcoError,
    onError = Color.Black,
)

@Composable
fun EcoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = EcoColorScheme,
        content = content
    )
}
