package com.example.eco

import android.net.Uri
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await

data class ProfileData(
    val uid: String = "",
    val displayName: String = "",
    val bio: String = "",
    val photoUrl: String? = null
)

data class PostData(
    val id: String = "",
    val authorUid: String = "",
    val text: String = "",
    val createdAt: Long = 0L,
    // Topic/feed
    val topicType: String = "", // "crypto" | "stock"
    val topicKey: String = "",  // coinId | stockSymbol
    val topicName: String = "",
    val reactions: Map<String, Long> = emptyMap()
)

data class CommentData(
    val id: String = "",
    val authorUid: String = "",
    val text: String = "",
    val createdAt: Long = 0L
)

class FirebaseRepo {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private val storage = FirebaseStorage.getInstance()

    fun uid(): String? = auth.currentUser?.uid

    suspend fun signUp(email: String, password: String, displayName: String) {
        auth.createUserWithEmailAndPassword(email, password).await()
        val u = uid() ?: error("UID null after signup")

        db.collection("users").document(u)
            .set(
                mapOf(
                    "email" to email,
                    "displayName" to displayName,
                    "bio" to "",
                    "photoUrl" to null,
                    "createdAt" to System.currentTimeMillis(),
                    "updatedAt" to System.currentTimeMillis()
                ),
                SetOptions.merge()
            )
            .await()
    }

    suspend fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password).await()
        val u = uid() ?: error("UID null after signin")

        db.collection("users").document(u)
            .set(
                mapOf(
                    "email" to email,
                    "lastLogin" to System.currentTimeMillis()
                ),
                SetOptions.merge()
            )
            .await()
    }

    fun logout() = auth.signOut()

    suspend fun getProfile(): ProfileData {
        val u = uid() ?: return ProfileData()
        val doc = db.collection("users").document(u).get().await()
        return ProfileData(
            uid = u,
            displayName = doc.getString("displayName") ?: "",
            bio = doc.getString("bio") ?: "",
            photoUrl = doc.getString("photoUrl")
        )
    }

    suspend fun uploadProfilePhoto(localUri: Uri): String {
        val u = uid() ?: error("UID null on uploadProfilePhoto")
        val ref = storage.reference.child("users/$u/profile.jpg")
        ref.putFile(localUri).await()
        return ref.downloadUrl.await().toString()
    }

    suspend fun updateProfile(displayName: String, bio: String, photoUrl: String?) {
        val u = uid() ?: error("UID null on updateProfile")
        val data = mutableMapOf<String, Any?>(
            "displayName" to displayName,
            "bio" to bio,
            "updatedAt" to System.currentTimeMillis()
        )
        if (photoUrl != null) data["photoUrl"] = photoUrl

        db.collection("users").document(u)
            .set(data, SetOptions.merge())
            .await()
    }

    suspend fun getFollowingUids(): List<String> {
        val u = uid() ?: return emptyList()
        val qs = db.collection("users").document(u).collection("following").get().await()
        return qs.documents.map { it.id }
    }

    suspend fun getFeedPosts(limit: Long = 50): List<PostData> {
        val following = getFollowingUids()
        if (following.isEmpty()) return emptyList()

        val chunk = following.take(10)
        val qs = db.collection("posts")
            .whereIn("authorUid", chunk)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(limit)
            .get()
            .await()

        return qs.documents.map { d ->
            PostData(
                id = d.id,
                authorUid = d.getString("authorUid") ?: "",
                text = d.getString("text") ?: "",
                createdAt = d.getLong("createdAt") ?: 0L,
                topicType = d.getString("topicType") ?: "",
                topicKey = d.getString("topicKey") ?: "",
                topicName = d.getString("topicName") ?: "",
                reactions = (d.get("reactions") as? Map<String, Any?>)?.mapValues { (_, v) ->
                    (v as? Number)?.toLong() ?: 0L
                } ?: emptyMap()
            )
        }
    }

    private fun feedId(topicType: String, topicKey: String): String = "$topicType:$topicKey"

    suspend fun createTopicPost(topicType: String, topicKey: String, topicName: String, text: String) {
        val u = uid() ?: error("Not authenticated")
        val fId = feedId(topicType, topicKey)
        val now = System.currentTimeMillis()

        // Ensure feed doc exists (useful for future listing)
        db.collection("feeds").document(fId)
            .set(
                mapOf(
                    "topicType" to topicType,
                    "topicKey" to topicKey,
                    "topicName" to topicName,
                    "updatedAt" to now
                ),
                SetOptions.merge()
            )
            .await()

        db.collection("feeds").document(fId)
            .collection("posts")
            .add(
                mapOf(
                    "authorUid" to u,
                    "text" to text,
                    "createdAt" to now,
                    "topicType" to topicType,
                    "topicKey" to topicKey,
                    "topicName" to topicName,
                    "reactions" to emptyMap<String, Long>()
                )
            )
            .await()
    }

    suspend fun getTopicPosts(topicType: String, topicKey: String, limit: Long = 50): List<PostData> {
        val fId = feedId(topicType, topicKey)
        val qs = db.collection("feeds").document(fId)
            .collection("posts")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(limit)
            .get()
            .await()

        return qs.documents.map { d ->
            PostData(
                id = d.id,
                authorUid = d.getString("authorUid") ?: "",
                text = d.getString("text") ?: "",
                createdAt = d.getLong("createdAt") ?: 0L,
                topicType = d.getString("topicType") ?: topicType,
                topicKey = d.getString("topicKey") ?: topicKey,
                topicName = d.getString("topicName") ?: "",
                reactions = (d.get("reactions") as? Map<String, Any?>)?.mapValues { (_, v) ->
                    (v as? Number)?.toLong() ?: 0L
                } ?: emptyMap()
            )
        }
    }

    suspend fun addReaction(topicType: String, topicKey: String, postId: String, emoji: String) {
        val fId = feedId(topicType, topicKey)
        val ref = db.collection("feeds").document(fId).collection("posts").document(postId)
        db.runTransaction { tx ->
            val snap = tx.get(ref)
            val reactions = (snap.get("reactions") as? Map<String, Any?>)?.toMutableMap() ?: mutableMapOf()
            val cur = (reactions[emoji] as? Number)?.toLong() ?: 0L
            reactions[emoji] = cur + 1L
            tx.update(ref, "reactions", reactions)
        }.await()
    }

    suspend fun addComment(topicType: String, topicKey: String, postId: String, text: String) {
        val u = uid() ?: error("Not authenticated")
        val fId = feedId(topicType, topicKey)
        db.collection("feeds").document(fId)
            .collection("posts").document(postId)
            .collection("comments")
            .add(
                mapOf(
                    "authorUid" to u,
                    "text" to text,
                    "createdAt" to System.currentTimeMillis()
                )
            )
            .await()
    }

    suspend fun getComments(topicType: String, topicKey: String, postId: String, limit: Long = 50): List<CommentData> {
        val fId = feedId(topicType, topicKey)
        val qs = db.collection("feeds").document(fId)
            .collection("posts").document(postId)
            .collection("comments")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .limit(limit)
            .get()
            .await()

        return qs.documents.map { d ->
            CommentData(
                id = d.id,
                authorUid = d.getString("authorUid") ?: "",
                text = d.getString("text") ?: "",
                createdAt = d.getLong("createdAt") ?: 0L
            )
        }
    }
}
