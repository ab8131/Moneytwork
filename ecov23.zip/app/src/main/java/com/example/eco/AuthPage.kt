// AuthPage.kt
package com.example.eco

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val email: String = "",
    val password: String = "",
    val displayName: String = "",
    val loading: Boolean = false,
    val error: String = ""
)

class AuthViewModel(private val repo: FirebaseRepo) : ViewModel() {
    private val _ui = MutableStateFlow(AuthUiState())
    val ui: StateFlow<AuthUiState> = _ui

    fun setEmail(v: String) { _ui.value = _ui.value.copy(email = v) }
    fun setPassword(v: String) { _ui.value = _ui.value.copy(password = v) }
    fun setDisplayName(v: String) { _ui.value = _ui.value.copy(displayName = v) }

    fun signIn(onOk: () -> Unit) = viewModelScope.launch {
        _ui.value = _ui.value.copy(loading = true, error = "")
        runCatching { repo.signIn(_ui.value.email.trim(), _ui.value.password) }
            .onSuccess {
                _ui.value = _ui.value.copy(loading = false)
                onOk()
            }
            .onFailure {
                it.printStackTrace()
                Log.e("AUTH_SIGNIN", it.message ?: "unknown", it)
                _ui.value = _ui.value.copy(loading = false, error = it.message ?: "Erreur")
            }
    }

    fun signUp(onOk: () -> Unit) = viewModelScope.launch {
        _ui.value = _ui.value.copy(loading = true, error = "")
        runCatching {
            repo.signUp(
                email = _ui.value.email.trim(),
                password = _ui.value.password,
                displayName = _ui.value.displayName.trim()
            )
        }
            .onSuccess {
                _ui.value = _ui.value.copy(loading = false)
                onOk()
            }
            .onFailure {
                it.printStackTrace()
                Log.e("AUTH_SIGNUP", it.message ?: "unknown", it)
                _ui.value = _ui.value.copy(loading = false, error = it.message ?: "Erreur")
            }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthPage(
    repo: FirebaseRepo,
    onAuthed: () -> Unit
) {
    val vm = remember { AuthViewModel(repo) }
    val ui by vm.ui.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("economie", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = ui.email,
            onValueChange = vm::setEmail,
            label = { Text("Email") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = ui.password,
            onValueChange = vm::setPassword,
            label = { Text("Mot de passe") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = ui.displayName,
            onValueChange = vm::setDisplayName,
            label = { Text("Nom (inscription)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (ui.error.isNotBlank()) {
            Text(ui.error, color = MaterialTheme.colorScheme.error)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { vm.signIn(onAuthed) },
                enabled = !ui.loading,
                modifier = Modifier.weight(1f)
            ) { Text("Se connecter") }

            Button(
                onClick = { vm.signUp(onAuthed) },
                enabled = !ui.loading,
                modifier = Modifier.weight(1f)
            ) { Text("S'inscrire") }
        }

        if (ui.loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
        }
    }
}
