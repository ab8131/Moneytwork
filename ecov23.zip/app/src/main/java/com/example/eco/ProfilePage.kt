package com.example.eco

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class ProfileUiState(
    val loading: Boolean = false,
    val error: String = "",
    val uid: String = "",
    val displayName: String = "",
    val bio: String = "",
    val photoUrl: String? = null
)

class ProfileViewModel(private val repo: FirebaseRepo) : ViewModel() {
    private val _ui = MutableStateFlow(ProfileUiState())
    val ui: StateFlow<ProfileUiState> = _ui

    private var newPhotoUri: Uri? = null

    fun setName(v: String) { _ui.value = _ui.value.copy(displayName = v) }
    fun setBio(v: String) { _ui.value = _ui.value.copy(bio = v) }
    fun setPickedPhoto(uri: Uri?) { newPhotoUri = uri }

    fun load() = viewModelScope.launch {
        _ui.value = _ui.value.copy(loading = true, error = "")
        runCatching { repo.getProfile() }
            .onSuccess { p ->
                _ui.value = ProfileUiState(
                    loading = false,
                    uid = p.uid,
                    displayName = p.displayName,
                    bio = p.bio,
                    photoUrl = p.photoUrl
                )
            }
            .onFailure { _ui.value = _ui.value.copy(loading = false, error = it.message ?: "Erreur") }
    }

    fun save(onSavedOk: () -> Unit) = viewModelScope.launch {
        _ui.value = _ui.value.copy(loading = true, error = "")
        runCatching {
            val uploadedUrl = newPhotoUri?.let { repo.uploadProfilePhoto(it) }
            repo.updateProfile(
                displayName = _ui.value.displayName.trim(),
                bio = _ui.value.bio.trim(),
                photoUrl = uploadedUrl
            )
        }
            .onSuccess {
                newPhotoUri = null
                _ui.value = _ui.value.copy(loading = false)
                load()
                onSavedOk()
            }
            .onFailure { _ui.value = _ui.value.copy(loading = false, error = it.message ?: "Erreur") }
    }

    fun logout() = repo.logout()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilePage(
    repo: FirebaseRepo,
    onLoggedOut: () -> Unit
) {
    val vm = remember { ProfileViewModel(repo) }
    val ui by vm.ui.collectAsState()

    var showOk by remember { mutableStateOf(false) }

    val pickImage = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        vm.setPickedPhoto(uri)
    }

    LaunchedEffect(Unit) { vm.load() }

    if (showOk) {
        AlertDialog(
            onDismissRequest = { showOk = false },
            confirmButton = {
                TextButton(onClick = { showOk = false }) { Text("OK") }
            },
            title = { Text("Enregistré") },
            text = { Text("Profil mis à jour.") }
        )
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("Profil") })

        Column(
            Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (ui.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (ui.error.isNotBlank()) Text(ui.error, color = MaterialTheme.colorScheme.error)

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AsyncImage(
                    model = ui.photoUrl,
                    contentDescription = "Photo de profil",
                    modifier = Modifier.size(72.dp).clip(CircleShape)
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("UID: ${ui.uid}", style = MaterialTheme.typography.labelMedium)

                    OutlinedButton(onClick = { pickImage.launch("image/*") }) {
                        Text("Choisir une photo")
                    }
                }
            }

            OutlinedTextField(
                value = ui.displayName,
                onValueChange = vm::setName,
                label = { Text("Nom") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = ui.bio,
                onValueChange = vm::setBio,
                label = { Text("Bio") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = { vm.save { showOk = true } },
                enabled = !ui.loading,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Enregistrer") }

            OutlinedButton(
                onClick = {
                    vm.logout()
                    onLoggedOut()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Déconnexion") }
        }
    }
}
