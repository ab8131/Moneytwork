package com.example.eco

data class TopicAsset(
    val type: String, // "crypto" | "stock"
    val key: String,  // coinId | stockSymbol
    val name: String,
    val symbol: String
) {
    val feedRoute: String get() = "feed_topic/${type}/${key}/${symbol}"
}
