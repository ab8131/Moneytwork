plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
}

// --- Build fix (Hilt / JavaPoet on Gradle classpath) ---
// The crash happens inside the Hilt Gradle plugin worker (hiltAggregateDeps),
// which runs on the *buildscript / plugin* classpath, not the app/module runtime classpath.
// Therefore we must also force JavaPoet on the buildscript classpath.
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        // Ensure the worker sees a JavaPoet version that has ClassName.canonicalName().
        classpath("com.squareup:javapoet:1.13.0")
    }
    configurations.classpath {
        resolutionStrategy.force("com.squareup:javapoet:1.13.0")
    }
}

// --- Build fix ---
// Hilt's Gradle aggregation task runs annotation processing on the Gradle worker classpath.
// If an older JavaPoet is pulled transitively, it can crash with:
//   NoSuchMethodError: com.squareup.javapoet.ClassName.canonicalName()
// Force a compatible JavaPoet version across all configurations.
allprojects {
    configurations.configureEach {
        resolutionStrategy.force("com.squareup:javapoet:1.13.0")
    }
}
